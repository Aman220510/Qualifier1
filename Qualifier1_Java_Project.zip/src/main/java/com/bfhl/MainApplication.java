package com.bfhl;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
import java.util.*;

@SpringBootApplication
public class MainApplication implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(MainApplication.class, args);
    }

    @Override
    public void run(String... args) {
        RestTemplate restTemplate = new RestTemplate();

        String initUrl = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("name", "John Doe");
        requestBody.put("regNo", "REG12347");
        requestBody.put("email", "john@gmail.com");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<Map> response = restTemplate.postForEntity(initUrl, request, Map.class);

            String webhookUrl = (String) response.getBody().get("webhookUrl");
            String accessToken = (String) response.getBody().get("accessToken");

            String finalQuery = "SELECT * FROM users;"; // TODO: Replace with real SQL answer

            Map<String, String> answer = new HashMap<>();
            answer.put("finalQuery", finalQuery);

            HttpHeaders answerHeaders = new HttpHeaders();
            answerHeaders.setContentType(MediaType.APPLICATION_JSON);
            answerHeaders.setBearerAuth(accessToken);

            HttpEntity<Map<String, String>> answerRequest = new HttpEntity<>(answer, answerHeaders);

            ResponseEntity<String> finalResponse = restTemplate.postForEntity(webhookUrl, answerRequest, String.class);

            System.out.println("Submitted Successfully: " + finalResponse.getBody());

        } catch (Exception e) {
            System.out.println("Something went wrong: " + e.getMessage());
        }
    }
}
